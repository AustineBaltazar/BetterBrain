package com.example.projectchecking;

public class Users {
    public String firstName;
    public String lastName;
    public String email;

    public Users(){

    }

    public Users(String firstName, String lastName, String email) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.email = email;
    }
}
